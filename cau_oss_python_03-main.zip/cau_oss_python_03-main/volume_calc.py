a = float(input("가로길이를 입력해 주세요 : "))
b = float(input("세로길이를 입력해 주세요 : "))
c = float(input("높이를 입력해 주세요 : "))

volume = a*b*c

print('박스의 부피는', volume, '입니다.')
